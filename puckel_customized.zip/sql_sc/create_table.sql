CREATE TABLE if NOT EXISTS  airflow.retail_data (
	stock_code varchar NULL,
	"desc" varchar NULL,
	country varchar NULL,
	total_price varchar NULL
);